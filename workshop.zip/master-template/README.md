# TERRAFORM

## Introducción

El software o programa que hemos realizado no está completamente terminado cuando todo está corriendo correctamente o cuando los test hayan pasado, el software está listo cuando ha sido lanzado o desplegado al usuario final.

Este despliegue consiste en todo el trabajo que se tiene que hacer para que el software sea accesible para el usuario, como por ejemplo correr el código en los servidores de producción. Para esto debemos gestionar una infraestructura de servidores, bases de datos, redes, etc.

## Infraestructura como código y cloud computing

Cuando hablamos de infraestructura como código nos referimos a un método de gestión de infraestructura y servicios a través del uso de código fuente, sustituyendo las operaciones manuales.

IaC consiste en manejar los servidores, bases de datos, redes y otros elementos de infraestructura como si fuera software. Este código facilita el despliegue y modificación de esta infraestructura de un modo rápido, seguro y consistente.

Se trata de una parte fundamental de la computación en la nube y esencial para DevOps.

## ¿Qué es Terraform?

`Terraform` es una herramienta open source desarrollado en Go, se usa para aprovisionar infraestructura mediante código declarativo. Permite automatizar y gestionar la infraestructura necesaria para desplegar plataformas y servicios sobre ella. También permite automatizar la gestión de estas plataformas y servicios una vez desplegados.

## ¿Para qué se usa Terraform?

`Terraform` se usa para simplificar la configuración de los recursos de infraestructura, lo que nos permite crear nueva infraestructura y la gestión de cambios en la misma mediante estados.

`Terraform` se integra con muchos proveedores de infraestructura, los más comunes son AWS,Google Cloud Platform (GCP), Azure, y Kubernetes. Estos proveedores nos exponen APIS de despliegue y de gestión de recursos.

## ¿Cómo funciona Terraform?

Con los archivos de configuración podemos indicar a `Terraform` los componentes necesarios para ejecutar una sola aplicación o toda su infraestructura. `Terraform` genera un plan de ejecución que describe lo que hará para llegar el estado deseado y luego se ejecuta para construir la infraestructura que describimos. A medida que cambia la configuración, `Terraform` puede determinar qué cambios se hicieron y crear nuevos planes de ejecución para editar, agregar o quitar componentes/recursos si asi lo requerimos.

# WORKSHOP (Instrucciones)

## Prerrequisitos

- Tener `Terraform` instalado.
- Tener una cuenta de Amazon Web Services (AWS).
- Tener una cuenta de Google cloud platform (GCP).

-----

**Instalar terraform en MAC**

Usaremos `homebrew` para instalar `Terraform` en mac,
Homebrew es un sistema de gestión de paquetes gratuito y de código abierto para Mac OS X.

Para verificar si tenemos homebrew ejecutamos el siguiente comando
```sh
brew -v
```

En caso de que no lo tengamos ejecutar lo siguiente para descargarlo y seguimos la instrucciones
```sh
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
```

Luego ejecutar el siguiente comando de brew para instalar `Terraform`
```sh
brew install terraform
```

-----
**Instalar terraform en Ubuntu/Debian**
 
ejecutar lo siguiente para añadir el HashiCorp GPG key.
```sh
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -
```

ejecutar lo siguiente para agregar el repositorio oficial de HashiCorp en linux.
```sh
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"
```
Luego instalaremos `Terraform` con el siguiente comando
```
sudo apt-get update && sudo apt-get install terraform
```
----

Para verificar la instalación de terraform ejecutamos el siguiente comando
```sh
terraform -help
```
-----

**Comandos basicos de Terraform**

A continuación se muestran los comandos más comunes utilizados en Terraform. 

La sintaxis para usar los comandos es:
```sh
terraform [-version] [-help] <command> [args]
```
- apply : Construye o actualiza la infraestructura definida.
- init : Inicia un directorio de trabajo de Terraform.
- plan : Genera y muestra el plan de ejecución. Permite ver cambios que se puedan generar al la infraestructura.
- show : Muestra los estados o planes de Terraform.
- validate : Valida los archivos de Terraform.
- destroy : Destruye la infraestructura que este siendo gestionada por Terraform.


> TIP : Los usuarios de bash  y zsh pueden habilitar el auto completado de comandos ejecutando la siguiente linea en la consola. 
>``` sh 
>terraform -install-autocomplete
>```
>Se recomienda reiniciar él interprete de comandos después de ejecutarla.

**Instalar plugin de VS-CODE**

Se recomienda instalar la siguiente extensión para el VS-CODE, esto nos ayudará con la sintaxis y autocompletado en los archivos de `Terraform`.

https://marketplace.visualstudio.com/items?itemName=HashiCorp.terraform

-----

## Instrucciones

**1.**
Cree un branch nuevo con el nombre 13-terraform-<su_nombre>.

**2.**
En el proyecto encontrara dos carpetas con los providers `AWS` y `GCP` en los que vamos a desarrollar los ejercicios, cada una de las carpetas tiene instrucciones especificas para su ejecución en el `README.md`, cuando termine las instrucciones de cada provider debe seguir las instrucciones finales que se muestran a continuación

-----

**3.** Utilice el comando `git status` para verificar qué archivos han cambiado.

**4.** Utilice el comando `git add` para agregar estos cambios.

**5.** Utilice el comando `git commit -m` con el siguiente mensaje: Workshop Typescript - Archivos con ejercicios actualizados.

**6.** Utilice el comando `git push` para enviar sus cambios y verifique en gitlab que estos están presentes *


*Nota:*
Para verificar los cambios en gitlab

En la página de gitlab, en el menú Overview hay un submenú llamado Activity. Al darle click aparecerá una lista con el historial de eventos del proyecto. Busque el evento relacionado con los cambios que necesite validar. Por ejemplo, para el punto 6 hay un evento que dice <su_nombre> pushed to branch 13-terraform-<su_nombre>. Abajo de este texto, hay un valor alfanumérico seguido del mensaje utilizado en el commit. Al darle click al valor alfanumérico abrirá una página mostrando los cambios realizados en ese commit.
Otra forma de llegar a esta página con los cambios es ir al menú Repository, submenú Commits. En la parte superior izquierda hay un selector con todos los branches existentes en el repositorio. Seleccione su branch (13-terraform-<su_nombre>). La lista se actualizará con el historial de commits para ese branch. Busque la fila que tenga el mensaje que utilizó en el commit, en la parte derecha encontrará el mismo valor alfanumérico el cual al darle click lo llevara a la página con los cambios.