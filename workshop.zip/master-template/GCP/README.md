# Instrucciones

### 1)
Debemos ubicarnos en la carpeta `GCP` en el terminal para empezar la implementación.
Para configurar el acceso a GOOGLE CLOUD se debe tener una llave de cuenta de servicio, para mayor información puede visitar
[este](https://cloud.google.com/iam/docs/creating-managing-service-account-keys) enlace.

Puede descargar las credenciales de las cuentas de servicio en formato json desde la consola, en la ruta:
>IAM & Admin -> Service accounts

Al hacer click sobre la cuenta podremos ir a las opciones de la cuenta y generar una nueva Key, como se muestra en la siguiente imagen.

![alt plan](./images/key.png)


configure la ruta a su llave de cuenta de servicio como variable de entorno:
``` sh
export GOOGLE_APPPLICATION_CREDENTIALS=<ruta_key>
export GOOGLE_CREDENTIALS=$(cat <ruta_key>)
```
### 2)
Vamos a usar el provider de GCP en este ejemplo, todas las instrucciones y declaraciones de `Terraform` las vamos a agregar a el archivo `GCP/main.tf`.
Para declarar el provider debemos agregar lo siguiente
```sh

provider "google" {
  project = "{{YOUR GCP PROJECT}}"
  region  = "us-central1"
  zone    = "us-central1-c"
}
````
Los elementos que podemos observar en la definición anterior son:

- project : El proyecto predeterminado que engloba los recursos que se desean administrar. 
- region : La región predeterminada donde se definan los recursos a administrar.
- zone : La zona predeterminada para administrar los recursos. Debe pertenecer a la 'region' especificada.

***Los valores definidos en el provider (project, region y zone) son opcionales. Si algún recurso define su propio project, region o zone, sera tomado el definido por el recurso***


> NOTA : Los projects en GCP funcionan como base de construcción y administración de todos los servicios ofrecidos por GCP, englobando recursos de infraestructura, Administración de API, Facturación, gestión de usuarios y permisos en un conjunto claramente identificable. 

### 3)
Cree un instancia de GCP:
Para crear nuestra instancia de GCP  agregar lo siguiente al archivo de configuración

```sh
resource "google_compute_instance" "vm_instance" {
  name         = "terraform-instance"
  machine_type = "f1-micro"
  tags         = ["terraform-instance"]

  boot_disk {
    initialize_params {
      #aqui se define la imagen base de la instancia (similar a las AMI en aws)
      image = "debian-cloud/debian-9"
    }
  }

  network_interface {
    # Se crea una red por defecto para todos los projects 
    network = "default"
    access_config {
    }
  }
}
```
>NOTA : Esta implementación creará recursos reales en su cuenta de GCP, por lo tanto debe seguir los ejercicios tal como aparecen sin poner otro tipo de instancias o datos, esto con el fin de evitar cargos adicionales en su cuenta. Asegurarse de ejecutar `terraform destroy` al final del ejercicio.

Las imágenes base pueden ser de naturaleza pública o privada, para más información sobre las imágenes base puede ver 
[este](https://cloud.google.com/compute/docs/images#os-compute-support) enlace.

Todas las imágenes disponibles las puede encontrar en su cuenta de GCP en:
> Compute Engine -> storage -> images

![alt images](./images/images.png)



### 4)
Por defecto esta VM instance está sobre una red que permite la comunicación por el puerto 22 (SSH) por tal motivo no es necesario añadir ninguna instrucción para habilitar este puerto, sin embargo si deseamos habilitar otro puerto si se requiere especificar qué puerto se desea habilitar utilizando un recurso denominado ```google_compute_firewall``` (Muy parecido a los security groups de AWS) y la instrucción ```allow``` de la siguiente manera.

```sh
resource "google_compute_firewall" "default" {
  name    = "https-firewall"
  #Es importante que la red sea la misma donde están nuestros recursos, en este caso nuestra instancia
  network = "default"
  
  #Se definen los puertos que se desean habilitar, se vuelve a habilitar el puerto 22 ya que el recurso por defecto sera modificado en su totalidad por lo que declaremos.
  allow {
    protocol = "tcp"
    ports    = ["80","443","22"]
  }
  #Esta opción solo aplica si definimos tags para nuestros recursos, lo cual es una buena práctica en Cloud.
  target_tags = ["terraform-instance"]
}
```
> NOTA: esto habilitará los puertos 80 -> http, 443 ->https y 22 ->ssh de la instancia.
De esta manera nuestro archivo tendrá la definición del provider y la definición de los 2 recursos.

Para validar esta configuración e iniciar los archivos de terraform use el comando ```terraform init```

### 5)
Si utilizamos el comando ``` terraform apply``` veremos algo similar a lo que se muestra en la siguiente imagen 


![alt plan](./images/plan.png)

 
 Lo que se puede identificar en la imagen anterior se le denomina 'execution plan' y muestra los recursos que Terraform va a ejecutar o a modificar. Si escribimos la palabra 'yes' Terraform ejecuta el plan y en unos pocos minutos podremos ver el recurso desde la consola de GCP.

![alt recurso](./images/recurso.png)

Desde la consola de GCP se puede visualizar la IP pública de la instancia (External IP) y conectarnos por medio de SSH.

### 6)

Supongamos que lo que deseamos es utilizar nuestra instancia como un servidor web, y por tal motivo queremos instalar nginx en nuestra instancia. Para realizar esta instalación podemos entrar por SSH y utilizar el comando ```sudo apt-get install nginx```, sin embargo esto no sería práctico y se aleja mucho de uno de los fundamentos de DevOps, la automatización. Usando Terraform podemos hacer esto de manera más elegante con una de las 3 siguientes opciones:

- Utilizando una imagen base que tenga ya instalado nginx (Muy similar a usar una AMI en AWS).
- Utilizando un script de aprovisionamiento en la definiciòn del recurso y enviarlo al recurso para su ejecución.
- Pasar los comandos de instalación en la definición del recurso como meta datos.

Por términos de tiempo usaremos la última opción para este workshop, entendiendo que ninguna de las opciones es la "mejor absoluta" ya que todas se pueden usar para casos concretos.

Para aprovisionar la máquina con nginx usaremos ```metadata_startup_script``` en la definición del recurso.
```sh
resource "google_compute_instance" "vm_instance" {
  #...
  metadata_startup_script = "sudo apt-get -y update;
  sudo apt-get -y install nginx"
  #...
}
```
### 7) 
Después de agregar los comandos para aprovisionar la instancia usamos el comando ``` terraform apply``` para ver y aceptar el plan de ejecución.

Al finalizar la actualización de los recursos podremos ver el servidor web corriendo en la IP pública de la instancia.

![alt plan](./images/nginx.png)

### 8) Utilizando los buckets de GCP con Terraform.

Para lanzar un bucket storage desde terraform se debe definir el recurso como lo hicimos con la instancia de vm, añadiendo al archivo lo siguiente.

```sh
resource "google_storage_bucket" "default" {
  name          = "terraform-bucket"
  location      = "EU"
  #la opción force_destroy indica que al momento de borrar el bucket no importa que este contenga objetos y será eliminado
  force_destroy = true
}
```

Utilizamos el comando ```terraform apply``` y aceptamos el plan de ejecución, pasados unos segundos podremos ir a la consola de GCP y ver el bucket creado.

![alt plan](./images/bucket.png)


### 9)
Desde el archivo donde definimos el recurso podemos subir objetos al bucket, esto usando la definición del recurso ```google_storage_bucket_object``` de la siguiente manera.

```sh
resource "google_storage_bucket_object" "picture" {
  name   = "butterfly01"
  source = "./images/mariposa.jpg"
  bucket = "terraform-bucket-vov"
}
```
Al utilizar el comando ```terraform apply``` y al aceptar el plan de ejecución podremos ir a la consola de GCP y ver el objeto que se ha subido al bucket.

![alt plan](./images/object.png)

### 10)
**Terminar la instancia - terraform destroy**
Al final de este workshop de GCP es importante que ejecutemos lo siguiente para terminar la instancia y borrar los buckets, con el fin evitar costos sobre el uso de estos recursos.
ejecutamos y aceptamos los cambios

```sh
terraform destroy
```



# CONSIDERACIONES

> Esta parte del WORKSHOP es opcional.

Si no se cuenta con la herramienta CLI de GCP (gcloud) conectarse a una instancia por SSH puede ser un poco tedioso. Por defecto cada project tiene una llave SSH para todos los recursos de Compute Engine, la cual se toma por defecto y puede ser cambiada usando Terraform. Si se desea tener una llave SSH para cada instancia se debe deshabilitar la llave SSH general de Compute Engine y generar la llave específica para cada instancia y especificarla en el recursos de VM instance de terraform. A continuación se muestra la forma de añadir una llave SSH general a Compute Engine y a instancias por separado.

## SSH KEY A NIVEL DE COMPUTE ENGINE.

### 1) Crear la llave.

```sh
sudo ssh-keygen -t rsa -f <key_path_name> -C <Username>
```
Con el comando anterior se crea una llave pública terminada en .pub y una privada.

### 2) Definir el recurso 

```sh
resource "google_compute_project_metadata" "default" {
  #Vamos a usar el recurso default que es el que se ha usado en este workshop 
  metadata = {
  #Se desactiva OS Login. De esta manera se puede ingresar desde cualquier otra consola.
    enable-oslogin  = false
    ssh-keys = "<Username>:${file("path/to/pub/key.pub")}"
  }
}
```

Después de añadir esto a nuestra definición de recursos y utilizar el comando ```terraform apply``` podremos utilizar la misma llave SSH con todas las instancias e ingresar desde nuestras estaciones de trabajo.

```sh
ssh -i <private_key_path>  <Username>@<External_IP>
```

## SSH KEY A NIVEL DE INSTANCIA.

Para poder usar llave SSH para cada instancia se debe eliminar la llave general de Compute Engine (ya que puede generar problemas a la hora de ejecutar SSH) y definir una llave en el recurso de VM Instance, como se muestra a continuación.

### 1) Crear la llave.

```sh
sudo ssh-keygen -t rsa -f <key_path_name> -C <Username>
```
Con el comando anterior se crea una llave pública terminada en .pub y una privada.

### 2) Añadir metadatos al recurso de VM Instance. 

```sh
resource "google_compute_instance" "vm_instance" {
  name         = "terraform-instance"
  machine_type = "f1-micro"
  zone         = "us-central1-a"
  #...
  metadata {
    ssh-keys = "<Username>:${file("path/to/pub/key.pub")}"
    block-project-ssh-keys = "TRUE"
  }
  #...
```

Después de añadir esto a nuestra definición de recursos y utilizar el comando ```terraform apply``` podremos utilizar nuestra llave privada para ingresar a la instancia.

```sh
ssh -i <private_key_path>  <Username>@<External_IP>
```