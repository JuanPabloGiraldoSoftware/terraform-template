> Nota: Esta implementación creará recursos reales en su cuenta de Amazon, se usan los recursos del `free tier` de AWS, por lo tanto debe seguir los ejercicios tal como aparecen sin poner otro tipo de instancias o datos, esto con el fin de evitar cargos adicionales en su cuenta.
Asegurarse de ejecutar `terraform destroy` al final del ejercicio.

## Conocimientos previos

**Básico**
- Terminal y linea de comandos: https://platzi.com/clases/terminal/ (ver si necesita reforzar o repasar de este tema)

**AWS - intermedio**
- Curso de Fundamentos de AWS Cloud: https://platzi.com/clases/aws-cloud/
- Curso de Cloud Computing con AWS: https://platzi.com/clases/aws-computo/ (Presentación, EC2, Lambda)
- Curso de Storage en AWS: https://platzi.com/clases/storage-aws/ (ver introducción y Sistema de archivos EFS y EBS)

**AWS - avanzado**
- Curso de Networking y Content Delivery en AWS: https://platzi.com/clases/networking-content/ (Introducción, Arquitectura en AWS, Route 53, API Gateway, Gateway, ver algunas Recetas)

> puede ver la ruta completa de aprendizaje de AWS services en caso que necesite reforzar en otro campo: https://platzi.com/aws/

**TERRAFORM**
- Curso de Infraestructura Como Código con Terraform: https://platzi.com/clases/devops-terraform/

## Prerequisitos
- Tener instalado el `awscli` v2

https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-mac.html

- Tener instalado `docker` y `docker-compose`

## Introducción

En este módulo de AWS-advanced implementaremos conceptos más avanzados de terraform como el manejo de variables, workspaces, environments, módulos, estados remotos, etc. de esta manera podemos implementar una estructura robusta y bien estructurada.

Se maneja el concepto de componentes para separar nuestros proyectos de terraform y se implementará una VPC y un cluster de ECS como ejemplo.

## Instrucciones

Debemos ubicarnos en la carpeta `AWS-advanced` en el terminal para empezar la implementación.

configure sus AWS access keys como variables de entorno:
```
export AWS_ACCESS_KEY_ID=<accessId>
export AWS_SECRET_ACCESS_KEY=<secretAccesskey>
export AWS_REGION=<aws-region>
```

# Crear VPC component

Debemos ubicarnos en la carpeta `terraform-project/vpc` en el terminal y los cambios en los archivos serán sobre este componente.

```bash
cd terraform-project/vpc
```

### 1)
Añadir provider al archivo `main.tf`

Para declarar el provider debemos agregar lo siguiente al archivo `main.tf`:

```sh
provider "aws" {
  region = var.region
}
```

Empezaremos a manejar el concepto de variables en este caso la región.

## Variables

Las variables de entrada sirven como parámetros para un módulo o componente de Terraform, nos permite personalizar datos del componente y permitir que se compartan entre diferentes configuraciones (por ej si queremos cambiar la región entre environments).

Terraform define los siguientes argumentos opcionales para declaraciones de variables:

- **default**: Es un valor predeterminado que luego hace que la variable sea opcional, se usa para determinar el valor por default que usaremos en la mayoría de configuraciones de nuestro componente.

- **type**: Este argumento especifica qué tipos de valores se aceptan para la variable, en versiones recientes de terraform el tipo se determina automáticamente.

- **description**: Especifica la documentación de la variable.

- **validation**: Es un bloque para definir las reglas de validación, generalmente además de las restricciones de tipo.

- **sensitive**: Limita la salida de la interfaz de usuario de Terraform cuando la variable se usa en la configuración.

ej.
```sh
variable "image_id" {
  type        = string
  description = "The id of the machine image (AMI) to use for the server."

  validation {
    # regex(...) fails if it cannot find a match
    condition     = can(regex("^ami-", var.image_id))
    error_message = "The image_id value must be a valid AMI id, starting with \"ami-\"."
  }
}
```

Empezaremos añadiendo las variables de región y el nombre de la aplicación, se agregaran el archivo `variables.tf`

```sh
#--------------------------------------------------------------------
# Terraform
#--------------------------------------------------------------------
variable "app_name" {
  default     = "VPC-workshop"
  description = "default app name"
}

variable "region" {
  default     = "us-east-1"
  description = "default region"
}
```

Para acceder a una variable usamos la siguiente expresión var.<NAME>
```
var.region
```

### 2)
Agregar recurso `vpc`

Para separar los recursos podemos crear otros archivos `.tf`, cuando se hace el plan de infraestructura terraform lee todos los archivos `.tf` del folder.

Crear el archivo `vpc.tf` y agregamos lo siguiente

```sh
#--------------------------------------------------------------------
# This module creates or uses existing VPC resources on AWS
# If the vpc_id variable is defined, it is understood that you want to work on an existing vpc,
# otherwise a new vpc will be created
#--------------------------------------------------------------------
locals {
  create_vpc = var.vpc_id == ""
}

module "vpc" {
  source          = "terraform-aws-modules/vpc/aws"
  name            = "${var.app_name}-vpc"
  cidr            = var.vpc_cird
  azs             = var.vpc_azc
  private_subnets = var.vpc_private_subnets
  public_subnets  = var.vpc_public_subnets
  create_vpc      = local.create_vpc # Conditional for create VPC (new)
}
```

## Locals

Un `local` asigna un valor a un nombre dentro de locals, por lo que se puede usar varias veces dentro de un módulo para no repetir un condición o expresión.

```
locals {
  create_vpc = var.vpc_id == ""
}
```

En este caso usaremos dentro del componente varias veces la expresión condicional `var.vpc_id == ""` y para evitar repetirlo lo asignamos a un local.

Los `locals` Son diferentes a las variables ya que los `locals` no los usamos para input values.

Para acceder a los valores de los `locals` usaremos la siguente expresión:

```
local.<NAME>
local.create_vpc
```

## Modulos

En el bloque anterior vemos el atributo `source` y la declaración `module "vpc"` lo que nos indica que es un módulo, en este caso un módulo externo oficial de terraform (VPC).

Un módulo es un contenedor de múltiples recursos y configuraciones, de esta manera podemos reutilizar configuraciones de recursos en diferentes proyectos.

Podemos usar módulos externos (repositorios o módulos oficiales) o módulos locales usando el path.

Cuando se ejecuta terraform Los archivos `.tf` en un folder crean un solo módulo raíz, ese módulo puede llamar a otros módulos y conectarse entre sí pasando `outputs` a valores de `inputs` de otros recursos. 

Los módulos se definen por lo general usando esta estructura

```
├── main.tf -> define los recursos y la configuración
├── outputs.tf -> define los outputs
└── variables.tf -> define los inputs
```

En este caso los atributos o `inputs` del modulo VPC son los siguientes:
```
name
cidr
azs
private_subnets
public_subnets
create_vpc
tags
```

también tendrá unos `outputs` que necesitaremos más adelante para otros recursos
```
vpc_id
public_subnets
private_subnets
```

Para acceder a los outputs de un módulo lo haremos de la siguiente manera:

```
module.<NAME>.<OUTPUT>
module.vpc.vpc_id
```

Usar el módulo de VPC nos ahorra el trabajo de crear los recursos de subnets, routables, igw y sus configuraciones.

### 3)
Crearemos `locals` y un datasource de vpc para definir los valores que necesitaremos para los outputs de nuestro componente VPC.

Añadir lo siguente al archivo `vpc.tf`

```sh
# ...

// Data & local values (subnets)
data "aws_vpc" "main" {
  id = local.create_vpc ? module.vpc.vpc_id : var.vpc_id
}

locals {
  public_subnets        = local.create_vpc ? module.vpc.public_subnets : var.vpc_public_subnets_ids
  private_subnets       = local.create_vpc ? module.vpc.private_subnets : var.vpc_private_subnets_ids
  public_subnets_cidrs  = local.create_vpc ? var.vpc_public_subnets : var.vpc_public_subnets_cidrs
  private_subnets_cidrs = local.create_vpc ? var.vpc_private_subnets : var.vpc_private_subnets_cidrs
}
```

## Data Sources

Los `Data Sources` nos sirven para hacer fetch o cálculo de datos para usar en cualquier otro lugar de la configuración de Terraform. Nos permiten usar configuraciones externas o de otra configuración de terraform.

En este caso definimos el datasource `aws_vpc` con id de la VPC creada condicionalmente:

```
data "aws_vpc" "main" {
  id = local.create_vpc ? module.vpc.vpc_id : var.vpc_id
}
```

Para obtener un valor de un datasource usamos la expresión:

```
data.<TYPE>.<NAME>.<ATTRIBUTE>
data.aws_vpc.main.id
```

A continuación en el archivo de outputs `outputs.tf` agregamos lo siguiente:

```sh
output "vpc_id" {
  value       = data.aws_vpc.main.id
  description = "VPC ID"
}

output "public_subnets" {
  value       = local.public_subnets
  description = "public subnets IDs"
}

output "private_subnets" {
  value       = local.private_subnets
  description = "private subnets IDs"
}

output "public_subnets_cidrs" {
  value       = local.public_subnets_cidrs
  description = "public subnets cidrs ex. [10.0.2.0/24, 10.0.3.0/24]"
}

output "private_subnets_cidrs" {
  value       = local.private_subnets_cidrs
  description = "private subnets cidrs ex. [10.0.0.0/24, 10.0.10.0/24]"
}
```

Los `outputs` son los valores de retorno del módulo o componente, más adelante las usaremos para definir la `vpc_id` y las subnets de otros componentes.

### 4)
Centralizar y crear default `tags`

Una parte importante del manejo de la infraestructura es definir los `tags` adecuadamente para evaluar billing, monitoring e identificar fácilmente los recursos creados.

Agregar lo siguiente al `main.tf`

```sh
# Tags
locals {
  default_tags = {
    Environment = terraform.workspace
    Project     = var.app_name
    Billing_Tag = "workshop"
  }
}
```

- **Environment**: Define el environment en este caso se define con el terraform workspace definido ej. `dev`

- **Project**: Define el proyecto al que pertenece el recurso en este caso usamos la variable `app_name` ej. `VPC-workshop`

- **Billing_Tag**: Identificador único del proyecto global por ej. `workshop`, para evaluar fácilmente el costo generado por los todos los recuros y componentes.

Agregar lo siguiente en la parte final del módulo `vpc` en el archivo `vpc.tf`:

```sh
module "vpc" {
  # ...

  tags = merge(
    {
      Name = "${var.app_name}-${terraform.workspace}"
    },
    local.default_tags,
    var.vpc_tags,
  )
}
```

En el caso del VPC necesitamos definir otros tags como el `Name` y en caso que necesitemos pasar un tag adicional podemos usar la variable `vpc_tags`

Podemos usar la función de terraform `merge()` para unir maps u objetos de diferentes sources y retornar uno solo

## Interpolation syntax

Podemos observar también que en terraform podemos usar la interpolación de las variables, es comúnmente usado como en este caso unimos el `app_name` y el `workspace` (env) para generar el `Name` de la vpc.

```sh
"${var.app_name}-${terraform.workspace}"
```

### 5)
Definir archivo de variables `tf.vars`

En este punto el componente de VPC ya está configurado pero necesitamos definir la variables que va a usar el componente para el deploy.

Para configurar las variables, lo más conveniente es especificar sus valores en un archivo de definiciones de variables `.tfvars` o `.tfvars.json`) y luego especificar ese archivo en la línea de comando con el flag `--var-file` al hacer el plan o el apply.

Para este ejercicio crearemos dos archivo de variables (`vars_dev.tfvars`, `vars_qa.tfvars`) con diferentes configuraciones entre los environments para entender el uso de los `.tfvars`.

Crear el archivo `vars_dev.tfvars` y  agregar lo siguiente:

```sh
# Terraform
app_name="boilerplate-VPC"
region="us-east-1"

// VPC config (NEW)
vpc_azc=["us-east-1a", "us-east-1b", "us-east-1c"]
```

Luego crear el archivo `vars_qa.tfvars` y  agregar lo siguiente:

```sh
# Terraform
app_name="boilerplate-VPC"
region="us-east-1"

// VPC config (NEW)
vpc_azc=["us-east-1a", "us-east-1b", "us-east-1c"]
vpc_cird="172.0.0.0/16"
vpc_private_subnets=["172.0.2.0/24", "172.0.3.0/24", "172.0.4.0/24"]
vpc_public_subnets=["172.0.0.0/24", "172.0.10.0/24", "172.0.20.0/24"]
```

En este caso vamos a definir otro CIDR block con una dirección de red diferente para la vpc de `qa`, esta es la utilidad que nos ofrecen los `.tfvars`, poder cambiar la definición de variables en diferentes files, por ej. si necesitaramos crear la vpc de `qa` o `dev` en otra región (`us-east-2`) podríamos hacerlo con los `.tfvars` y la misma configuración del componente.

También podemos observar en el tfvars de `dev` no definimos algunas variables, en este caso terraform usará los `defaults` que se definieron para esa variable.

### 6)
Definir estado remoto (también llamado `backend` en terraform)

Como pudimos observar en el primer `workshop`, terraform guarda el estado de nuestra infraestructura de forma local, con esto se guarda la última configuración y terraform sabe qué recursos se encuentran actualmente desplegados.

Este estado se almacena de forma predeterminada en un archivo local llamado `terraform.tfstate`, pero también se puede almacenar de forma remota, lo que funciona mejor en un entorno de equipo y trabajo colaborativo.

Para este ejemplo guardaremos el estado remoto en un bucket de `s3` y en el bucket podemos separar por keys y environment los componentes de nuestro proyecto.

Crear el siguiente recurso temporalmente en `main.tf` para crear el bucket

```sh
resource "aws_s3_bucket" "backend" {
  bucket = "workshop-tfstates-<mi nombre>-<mi apellido>"
  acl    = "private"
  tags   = { Name = "workshop-tfstate" }
}
```

Llamaremos a nuestro bucket `workshop-tfstates-<mi nombre>-<mi apellido>` por favor asegurarse de cambiar los valores de nombre y apellido.

Asegurarnos que en este punto ya tenemos nuestras credenciales exportadas y ejecutamos lo siguiente en el terminal y confirmamos:

```sh
terraform init
terraform apply -target=aws_s3_bucket.backend
```

Deberíamos ver un solo recurso en el plan ya que usamos el flag `-target` de terraform para crear solo el bucket.

Al final debemos ver el bucket creado en la consola en `s3`

<Insertar imagen aqui>

Luego agregaremos la configuración de nuestro backend remoto al archivo `main.tf`

```sh
terraform {
  backend "s3" {
    bucket = "workshop-tfstates-<mi nombre>-<mi apellido>"
    key    = "vpc/terraform.tfstate"
    region = "us-east-1"
  }
}
```

> Si se creó el bucket en otra región debe cambiar el atributo `region`

También debemos borrar el recurso temporal del bucket creado ya que no lo queremos en nuestra configuración, solo usamos terraform como un medio para crearlo.

Luego ejecutar `terraform init` y denegamos la opción de "copy local state" al nuevo backend bucket, esto con el fin de evitar que el bucket lo tome en el estado, ya que no queremos destruirlo junto con la infraestructura después:

```
terraform init
```

```
Enter a value: no
```

### 7)
Establecer o crear el espacio de trabajo (`workspace`) de terraform

## Workspaces

Cada configuración de Terraform tiene un `backend` asociado que define cómo se ejecutan las operaciones y dónde se almacena el estado.

Los datos persistentes almacenados en el backend pertenecen a un `workspace`. Inicialmente, el backend tiene solo workspace, llamado `default` y, por lo tanto, solo hay un estado de Terraform asociado con esa configuración.

La idea es que los tags y la configuración de terraform sea separada por `environments` o `workspaces` por eso crearemos dos `workspaces` (`dev` y `qa`).

Estos `workspaces` deben ser creados en cada componente, ya que cada uno tiene un backend y estado remoto asociado independiente.

Para crear los `workspaces` ejecutamos lo siguiente: 

```bash
terraform workspace new dev
terraform workspace new qa
```

para seleccionar un workspace que ya existe:

```bash
terraform workspace select dev
```

para comprobar el workspace seleccionado:
```bash
 terraform workspace show
```

> SUGERENCIA: La mejor manera de administrar los `workspaces` de terraform una vez han sido creados, es a través de un env var, porque se usará en los otros componentes, por ejemplo, en la acción de cambio de directorio (cd).

exportar la siguiente variable de entorno en la terminal:

```sh
export TF_WORKSPACE=dev
```

### 8)
Deploy VPC `dev` and `qa`

Debemos especificar el archivo de variables (creado en el `paso 5`) que vamos a usar además del workspace, para esto usamos el flag `--var-file=`

Ejecutamos el siguiente comando para hacer deploy de `dev` usando el archivo de variables `vars_dev.tfvars`

```sh
terraform apply --var-file=vars_dev.tfvars
```

Verificamos que el plan esté correcto y que el workspace seleccionado sea `dev` y confirmamos los cambios

<Insertar imagen aquí>

Ahora haremos deploy de la vpc de `qa` debemos cambiar el `workspace` antes de aplicar los cambios

```sh
export TF_WORKSPACE=qa
```

luego usamos el otro archivo de variables `vars_qa.tfvars` ya que queremos otra configuración para nuestra vpc de `qa`

```sh
terraform apply --var-file=vars_qa.tfvars
```

Verificamos que el plan esté correcto y que el workspace seleccionado sea `qa` y confirmamos los cambios

<Insertar imagen aquí>

Si todo salió correctamente debemos ver lo siguiente en la sección de `VPC` en el aws console:

<Insertar imagen aqui>

-----------

# Crear Módulos locales

Para avanzar en el proyecto debemos crear algunos módulos locales, como vimos en el ejemplo anterior de la `vpc` hacíamos referencia a un módulo externo, pero en este caso se van a crear **3** módulos de manera local que nos servirán para centralizar algunos recursos y configuraciones de nuestro proyecto y de esta manera podremos usarlos en los distintos componentes que creemos más adelante.

**autoscaling-group:** Este módulo crea un autoscaling group con un launch template y también tiene la opción de crear autoscaling policies y autoscaling schedule si así se requiere.

**ecs:** En este módulo creamos un cluster de ecs con las configuraciones necesarias para crear este, como el `service`, `task definition`, `capacity provider`, `log groups`, etc.

**ecs-lb-security-groups:** En este módulo se crea la configuración común para los security groups de un `load balancer` y las instancias en el cluster.

Debemos ubicarnos en la carpeta `terraform-project/modules` para el cambio de estos archivos

> Los archivos `.tf` de los módulos locales ya vienen creados y se agregaron los `outputs` y las `variables` que son conceptos que ya hemos estudiado y no es necesario agregarlos de nuevo desde el readme, nos enfocaremos en los recursos y su configuración.

> Cuando empecemos a pasar los recursos de los módulos usaremos las variables definidas, por favor revisar estas variables en los archivos `variables.tf` respectivos para tener claro lo que se está implementando. 

#--------------------------------------------------------------------
### Autoscaling group module
#--------------------------------------------------------------------

Para el desarrollo de este módulo debemos ubicarnos en la carpeta `terraform-project/modules/autoscaling-group`

### 1)
Agregar `instance profile`

Para que las instancias se comuniquen con otros servicios y gestionar sus permisos es necesario configurar un `instance profile` que es el que se encarga de pasar un `IAM role` determinado a las instancias, en este caso crearemos esta configuración en el archivo `instance_role.tf`.

Agregar lo siguiente al archivo `instance_role.tf`:

```sh
locals {
  create_instance_role = var.default_instance_role_arn == ""
}

resource "aws_iam_role" "ecs-instance-role" {
  count              = local.create_instance_role ? 1 : 0
  name               = "boilerplate-ecs-instance-role-${var.name}"
  path               = "/"
  assume_role_policy = <<EOF
{
  "Version": "2008-10-17",
  "Statement": [
    {
      "Action": "sts:AssumeRole",
      "Principal": {
        "Service": ["ec2.amazonaws.com"]
      },
      "Effect": "Allow"
    }
  ]
}
EOF
}

resource "aws_iam_role_policy_attachment" "ecs-instance-role-attachment" {
  count      = local.create_instance_role ? 1 : 0
  role       = aws_iam_role.ecs-instance-role[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonEC2ContainerServiceforEC2Role"
}

resource "aws_iam_instance_profile" "ecs_service_role" {
  count = local.create_instance_role ? 1 : 0
  role  = aws_iam_role.ecs-instance-role[0].name
}
```

Algo interesante que se empieza a hacer en este módulo es el uso del atributo `count` para condicionar la creación de algunos recursos: 

```sh
count = local.create_instance_role ? 1 : 0
```

A los recursos en terraform se le puede pasar el número de recursos que queremos que cree, cuando agregamos esto el retorno del `output` se convierte en un arreglo, entonces debemos acceder de esta manera si queremos acceder a determinado índice:

```sh
aws_iam_instance_profile.ecs_service_role[0].arn
```

El uso del count en este caso es para condicionar que no se cree el recurso en caso que la variable `default_instance_role_arn` esté definida, ya que al pasar este `arn` decimos que fue creado anteriormente en la consola.

### 2)
Agregar `autoscaling group`

Agregaremos el `autoscaling group` junto con el `placement group`, para consultar qué atributos podemos pasar en los recursos simplemente buscamos en la documentación oficial el nombre del recurso (`aws_autoscaling_group`).

Agregar lo siguiente al archivo `main.tf`:

```sh
resource "aws_placement_group" "placement-group" {
  name     = var.name
  strategy = var.placement_strategy
  tags     = var.tags
}

resource "aws_autoscaling_group" "auto-scalling" {
  name                      = var.name
  min_size                  = var.minSize
  max_size                  = var.maxSize
  desired_capacity          = var.desired_capacity
  placement_group           = aws_placement_group.placement-group.id
  health_check_grace_period = var.health_check_grace_period
  health_check_type         = var.health_check_type
  vpc_zone_identifier       = var.vpc_zone_identifier
  target_group_arns         = var.target_group_arns
  protect_from_scale_in     = var.protect_from_scale_in

  timeouts {
    delete = var.timeout_delete
  }

  tags = var.autoscaling_tags

  lifecycle {
    create_before_destroy = true
  }

  launch_template {
    id      = aws_launch_template.ec2.id
    version = var.launch_template_version
  }
}
```

Como podemos observar todos los atributos son configurables por medio de variables, podemos configurar el `max_size`, `min_size`, etc. como nos convenga.

### 3)
Agregar `autoscaling policy`

La política de autoscaling se encarga de determinar cuando puede hacer `scale in` o `scale out` mediante su configuración, la más común es medir la capacidad de `cpu` con un `target_value` determinado y así agregar más instancias si es necesario.

Agregar lo siguiente al archivo `main.tf`:

```sh
# ...

resource "aws_autoscaling_policy" "cpu-scaling" {
  count                     = var.create_autoscaling_policy ? 1 : 0
  name                      = var.policy_name
  adjustment_type           = var.adjustment_type
  estimated_instance_warmup = var.instance_warmup
  policy_type               = var.policy_type
  autoscaling_group_name    = aws_autoscaling_group.auto-scalling.name

  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = var.metric_type
    }
    target_value = var.target_value
  }
}
```

Es un recurso que también está condicionando por medio de una variable `create_autoscaling_policy` en caso que no queramos policies por ej `ecs` gestiona el autoscaling cuando usamos un `capacity provider` y no es necesario crear un política específica.

```sh
count = var.create_autoscaling_policy ? 1 : 0
```

### 4)
Agregar `launch template`

El `launch template` es el template que usará el `autoscaling group` para lanzar las nuevas instancias cuando así se requiera, incluye información como el `storage`, `instance type`, `ami`, `network_interfaces`, etc.

Agregar lo siguiente al archivo `main.tf`:

```sh
# ...

resource "aws_launch_template" "ec2" {
  name                   = var.launch_template_name
  update_default_version = var.update_default_version

  block_device_mappings {
    device_name = var.root_volume_name

    ebs {
      volume_type           = var.ebs_volume_type
      volume_size           = var.root_volume_size
      delete_on_termination = var.delete_on_termination
    }
  }

  iam_instance_profile {
    arn = local.create_instance_role ? aws_iam_instance_profile.ecs_service_role[0].arn : var.default_instance_role_arn
  }

  image_id      = data.aws_ami.amazon_linux.id
  instance_type = var.instance_type
  key_name      = var.key_name

  network_interfaces {
    security_groups = var.sec_ids
  }

  tag_specifications {
    resource_type = var.tag_resource_type
    tags = merge(
      {
        Name = var.name
      },
    var.tags, )
  }

  user_data = base64encode(templatefile("${path.cwd}/templates/${var.userDataFile}", var.templateVars))
}
```

Podemos notar que aquí tenemos un condicional para usar el `instance profile` creado desde terraform o configurado desde variables según sea el caso:

```sh
  iam_instance_profile {
    arn = local.create_instance_role ? aws_iam_instance_profile.ecs_service_role[0].arn : var.default_instance_role_arn
  }
```

También podemos agregar un script en el `user_data` para que ejecute tareas o configuraciones al momento de crear la instancia, por ej. se puede pasar un template con configuraciones de `ecs` o de servidores web.

```sh
  user_data = base64encode(templatefile("${path.cwd}/templates/${var.userDataFile}", var.templateVars))
```

### 5)
Agregar `aws autoscaling schedule`

Para nuestro módulo de `autoscaling group` podemos configurar o no un `schedule` para cambiar algunas configuraciones, esto sería útil por ejemplo para reasignar el número de instancias que se necesitan a determinada hora dependiendo del tráfico de nuestra app.

Agregar lo siguiente al archivo `main.tf`:

```sh
# ...

resource "aws_autoscaling_schedule" "lowUsage" {
  count                  = var.enable_autoscaling_schedule ? 1 : 0
  scheduled_action_name  = var.lowUsage_scheduled_action_name
  desired_capacity       = var.lowUsage_desired_capacity
  max_size               = var.lowUsage_max_size
  min_size               = var.scheduledMinSizeLow
  recurrence             = var.lowUsage_recurrence
  autoscaling_group_name = aws_autoscaling_group.auto-scalling.name
}

resource "aws_autoscaling_schedule" "highUsage" {
  count                  = var.enable_autoscaling_schedule ? 1 : 0
  scheduled_action_name  = var.highUsage_scheduled_action_name
  desired_capacity       = var.highUsage_desired_capacity
  max_size               = var.highUsage_max_size
  min_size               = var.scheduledMinSizeHigh
  recurrence             = var.highUsage_recurrence
  autoscaling_group_name = aws_autoscaling_group.auto-scalling.name
}
```

Igualmente podemos notar que aquí tenemos un condicional para crear el `schedule` o no según sea el caso:

```sh
count = var.enable_autoscaling_schedule ? 1 : 0
```

### 6)
Agregar `Amazon Machine Images (AMI) datasource`

Por medio de las variables del `ami datasource` podemos determinar de manera dinámica que imagen va usar el template de la instancia.

Agregar lo siguiente al archivo `main.tf`:

```sh
# ...

data "aws_ami" "amazon_linux" {
  most_recent = true

  dynamic "filter" {
    for_each = var.filters
    content {
      name   = filter.value.name
      values = filter.value.values
    }
  }

  owners = var.ami_owners
}
```

En este punto hemos terminado la configuración del módulo del `autoscaling`, como podemos observar en este módulo local ponemos las configuraciones comunes que se usan en el `autoscaling` y de esta manera poderlo usar en todos nuestros componentes, evitando repetir esto en cada uno.

#--------------------------------------------------------------------
### ecs module
#--------------------------------------------------------------------

#--------------------------------------------------------------------
### ecs-lb-security-groups module
#--------------------------------------------------------------------

-----------

# Crear ECS cluster component

Debemos ubicarnos en la carpeta `terraform-project/workshop-server` en el terminal y los cambios en los archivos serán sobre este componente.

```bash
cd terraform-project/workshop-server
```

### 1)
Añadir provider al archivo `main.tf`

Para declarar el provider debemos agregar lo siguiente al archivo `main.tf`:

```sh
provider "aws" {
  region = var.region
}
```

### 2)
Definir estado remoto (también llamado `backend` en terraform)

Para configurar el estado remoto de terraform en los componente simplemente agregamos lo siguiente al `main.tf`

```sh
# ...

terraform {
  backend "s3" {
    bucket = "workshop-tfstates-<mi nombre>-<mi apellido>"
    key    = "workshop-server/terraform.tfstate"
    region = "us-east-1"
  }
}
```

Recordemos que anteriormente cuando creamos la vpc se creó el bucket para guardar los estados de todos los componentes.

Asegúrese de cambiar el nombre del bucket por el que se haya definido anteriormente.

### 3)
Crear el datasource para obtener la VPC

Cuando creamos componentes en nuestro proyecto que necesitan acceder a la `vpc`, debemos crear un datasource para obtener el output que definimos cuando creamos la `vpc` (`vpc_id`, `subnets`, `cird`).

Agregar lo siguiente al archivo `main.tf` para agregar el `datasource`

```sh
# ...

data "terraform_remote_state" "vpc" {
  backend = "s3"

  config = {
    bucket = "workshop-tfstates-<mi nombre>-<mi apellido>"
    key    = "env:/${terraform.workspace}/vpc/terraform.tfstate"
    region = "us-east-1"
  }
}
```

- **backend:** El tipo de backend remoto que se está usando.

- **bucket:** Bucket donde se encuentra guardado el estado remoto, asegúrese de cambiar el nombre del bucket porque se haya definido anteriormente.

- **key:** Ubicación del estado remoto que queremos obtener, podemos observar el prefijo `env` en este caso `env:/${terraform.workspace}/` por que cuando usamos `workspaces` terraform separa los workspaces usando este prefijo. ej `env:/dev/vpc/terraform.tfstate` o `env:/qa/vpc/terraform.tfstate`.

- **region:** Región donde se guardó el bucket.

Para declarar un datasource empezamos un bloque con la palabra `data`.

Un data block lee la fuente de datos determinada (`terraform_remote_state`) y exporta el resultado con el nombre definido (`vpc`). El nombre se utiliza para hacer referencia a este recurso desde cualquier otro lugar del mismo folder de Terraform.

Por ejemplo si queremos acceder a los `outputs` de este datasource lo hacemos de la siguiente manera:

```sh
data.terraform_remote_state.vpc.outputs.vpc_id
```

### 4)
Centralizar y crear default `tags`

Agregar lo siguiente al `main.tf`

```sh
# Tags
locals {
  default_tags = {
    Environment = terraform.workspace
    Project     = var.app_name
    Billing_Tag = "boilerplate"
  }
  default_object_tags = [
    {
      "key"                 = "Environment"
      "value"               = terraform.workspace
      "propagate_at_launch" = true
    },
    {
      "key"                 = "Project"
      "value"               = var.app_name
      "propagate_at_launch" = true
    },
    {
      "key"                 = "Billing_Tag"
      "value"               = "boilerplate"
      "propagate_at_launch" = true
    },
  ]
}
```

En este caso estamos definiendo los mismos tags que se definieron para la `vpc` pero adicionalmente agregamos `default_object_tags` que son tags definidos como objetos y que son usados de esta forma por componentes como el `autoscaling group`.

- **key:** Key del tag.

- **value:** Valor asignado al tag.

- **propagate_at_launch:** Habilita la propagación de los tags a instancias lanzadas a través del `autoscaling group`.

### 5)
Centralizar outputs de la `vpc`

En nuestro cluster de ecs debemos definir el `vpc_id` o las `subnets` en diversos recursos por eso vamos a centralizar los outputs en un `.tf`.

Crear file `vpc.tf` y agregar lo siguiente:

```sh
#--------------------------------------------------------------------
# Local data and values to group and centralize VPC resource values
#--------------------------------------------------------------------
data "aws_vpc" "main" {
  id = data.terraform_remote_state.vpc.outputs.vpc_id
}

locals {
  public_subnets        = data.terraform_remote_state.vpc.outputs.public_subnets
  private_subnets       = data.terraform_remote_state.vpc.outputs.private_subnets
  public_subnets_cidrs  = data.terraform_remote_state.vpc.outputs.public_subnets_cidrs
  private_subnets_cidrs = data.terraform_remote_state.vpc.outputs.private_subnets_cidrs
}
```

Como podemos ver definimos `locals` para usarlos en todo el componente.

Del `datasource` obtenemos los `outputs` que definimos en la vpc en el **paso 3** de la sección de crear `vpc`.


------
------

# Build and push image to ECR
ejecutar

```
terraform apply
```

exportar las variables de entorno para ejecutar el script y subir la imagen al registry (ECR)
```
export IMAGE_REPO_NAME=workshop-ecr-repo
export IMAGE_TAG=latest
export AWS_ACCOUNT_ID=<account_id>
```

Run the next command to upload image to ECR
```
sh buildimage.sh
```