const express = require('express')
const app = express()
const port = 3000

app.get('/', (req, res) => {
  res.send('Root success response |SERVER|');
})

app.get('/health-check', (req, res) => {
  res.status(200).send('OK |SERVER|');
})

app.get('/users', (req, res) => {
  res.status(200).send('USERS RESPONSE');
})

const server = app.listen(port, () => console.log(`app listening on port ${port}!`));

server.keepAliveTimeout = 65000; // Ensure all inactive connections are terminated by the ALB, by setting this a few seconds higher than the ALB idle timeout
server.headersTimeout = 66000; 