# boilerplate-terraform

## Prerequisites

- Amazon EC2 "key pair" created in AWS console. The "key pair" is used for launch template resource.

## Components

The infrastructure is separated into components, each component has the terraform configuration inside and it runs individually, at the moment the order to deploy the components is to run the VPC before the other components, since the VPC is used by them.

```
1. vpc
2. component-server
```

The component-server reads the vpc through Datasource called `terraform_remote_state` and get the outputs of the state ex. vpc id, subnets ids, cidrs, etc.

## Deployment

The deployment for QA and PROD should be executed through the pipeline (CI) in the following branches:

```
staging -> qa workspace
master -> prod workspace
```

> Important: The deployment for QA and PROD shouldn't be applied to your local computer, only through the bitbucket pipeline (CI).

## Environments management

The environments are managed by Terraform workspaces (dev, qa, prod) and the specific configuration by environments (for example, `instance types` or `instance sizes`) are managed by .tfvars files.

The `.tfvars` and `workspaces` combination allow us to manage to terraform states, environment tags in resources, specific configurations by envs and resources names.

ex. terraform apply for dev environment
```
export TF_WORKSPACE=dev
terraform apply --var-file=vars_dev.tfvars
```

## Modules

**External modules**

| Module             | Description                                                  |
| ------------------ | :----------------------------------------------------------- |
| terraform-aws-modules/vpc/aws  | Terraform module which creates VPC resources on AWS. (vpc, subnets, routables, igw)             |
| terraform-aws-modules/alb/aws  | Terraform module which creates Application Load Balancer resources on AWS. (elb, tg, listeners) |

**Local modules**

| Module             | Description                                                  |
| ------------------ | :----------------------------------------------------------- |
| modules/autoscaling-group       | Local module which creates autoscaling group resources (asg, launch template, policies, schedules).   |
| modules/ecs                     | Local module which creates ECS resources (cluster, c. provider, service, task definition, log group). |
| modules/ecs-lb-security-groups  | Local module which centralize security groups implementation and rules for ECS and LB                 |

----
## Steps to run infra (Local deployment for tests)

This steps should be applied only for `dev` environment

### 1) Configure your AWS access keys as environment variables:

```bash
export AWS_ACCESS_KEY_ID=<your access key id>
export AWS_SECRET_ACCESS_KEY=<your secret access key>
export AWS_REGION=<region>
```

### 2) Configure remote state

If you run the code for the first time configure the remote state, Follow the instructions in the [Setup-backend(first-time)](#Setup-backend(first-time)) section.

### 3) Set or create the terraform workspace ex. `dev`

```bash
terraform workspace new dev
```

or select if exist

```bash
terraform workspace select dev
```

to check environment selected 

```bash
 terraform workspace show
```

> TIP: The best way to manage terraform workspace is through env var because it will be used in the other components, on change directories action for instance.

> the workspace must be previously created

```bash
export TF_WORKSPACE=dev
```

### 4) Change to component directory

First change directory to `VPC` component and run the apply instructions (5)

```bash
cd vpc/
```

Then change directory to `component-server` components and run the apply instructions (5)

```bash
cd component-server/
```

### 5) Init terraform with new workspace:

```bash
terraform init
```

### 6) Deploy the components and select var file ex. `dev`

```bash
terraform apply --var-file=vars_dev.tfvars
```

> TIP: always check if the correct changes will be applied in the changes plan on the console gui.

### 7) If you need to destroy infrastructure ex. `dev`

First Terminate instances associated to components or delete autoscaling groups - due to scale in delete protection.

> Make sure to unlink the resources that have been modified manually in the console, ex security groups or tg forward in listeners.

> Make sure to setup `terraform workspace`

First run destroy command  in components
```bash
cd component-server/
```

Then run destroy command in VPC
```bash
cd vpc/
```

*destroy command*
```bash
terraform destroy --var-file=vars_dev.tfvars
```

----
----

## Setup-backend(first-time)

> To facilitate collaborative work and have a single point where the states are stored we must define a backend

If the backend bucket isn't created yet for terraform remote state follow the next instructions:

### 1) Change diretory to VPC comp
```bash
cd vpc
```

### 2) Comment the backend config inside `main.tf` file:

```
# terraform {
#   backend "s3" {
#     bucket = "boilerplate-terraform-states"
#     key    = "vpc/terraform.tfstate"
#     region = "us-east-1"
#   }
# }
```

**Important:** check the region exported

### 3) Add the next resource temporarily in the `main.tf` to create an AWS bucket with terraform

```
resource "aws_s3_bucket" "backend" {
  bucket = "boilerplate-terraform-states"
  acl    = "private"
  tags   = { Name = "boilerplate-tfstate" }
}
```

> If you change the bucket name `boilerplate-terraform-states` for the name of your project, make sure to change it in all components (search for `backend "s3"` in the other components)

### 4) Run the next commands to create backend bucket:

```
terraform init
terraform apply -target=aws_s3_bucket.backend
```

> If you have problem executing `terraform init` check [Troubleshooting](#Troubleshooting) section.

### 5) Uncomment the backend config inside `main.tf` file and delete temporarily aws bucket resource.

### 6) Run init and denied the option to copy local state to new backend bucket:

```
terraform init
```

```
Enter a value: no
```

Delete local states .tfstates or backups created.

> The bucket creation should be applied only once because all the components states will be saved with specific key

## Encrypt backend (Optional)

You can encrypt the s3 backend if you have sensitive data inside:

https://www.terraform.io/docs/language/state/sensitive-data.html

https://www.terraform.io/docs/language/settings/backends/s3.html#encrypt

-----
-----
## Troubleshooting

### 1) If you have the next error when running the command to create the backend bucket.

```
Error: Error loading state: S3 bucket does not exist.

The referenced S3 bucket must have been previously created. If the S3 bucket
was created within the last minute, please wait for a minute or two and try
again.

Error: NoSuchBucket: The specified bucket does not exist
```

Delete the `.terraform` folder, then comment the backend config inside `main.tf` file and start the process again.